<!--Inserting Images-->
  <div id="background-image">
    <div id="image-1"></div>
    <div id="image-2"></div>
  </div>
